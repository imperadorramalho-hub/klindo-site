SITE INSTITUCIONAL KLINDO

Para visualizar: abra index.html no navegador.
Para publicar: envie a pasta inteira (index.html e assets) para uma hospedagem estática, como Vercel, Netlify ou Hostinger.
WhatsApp em todos os CTAs: +55 11 91967-1325.
O Instagram é um endereço ilustrativo e deve ser confirmado antes da publicação.
O site não coleta dados nem envia formulários: os contatos abrem diretamente no WhatsApp.
Para personalizar serviços, textos e paleta, edite index.html.
